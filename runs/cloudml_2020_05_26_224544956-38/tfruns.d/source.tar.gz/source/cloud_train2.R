cloud_train2 <- function(file = "train.R", master_type = NULL, flags = NULL, 
          region = NULL, config = NULL, collect = "ask", dry_run = FALSE) 
{
  if (dry_run) 
    message("Dry running training job for CloudML...")
  else message("Submitting training job to CloudML...")
  gcloud <- cloudml:::gcloud_config()
  cloudml <- cloudml:::cloudml_config(config)
  if (!is.null(master_type)) 
    cloudml$trainingInput$masterType <- master_type
  if (!is.null(cloudml$trainingInput$masterType) && !identical(cloudml$trainingInput$scaleTier, 
                                                               "CUSTOM")) 
    cloudml$trainingInput$scaleTier <- "CUSTOM"
  if (length(cloudml) == 0L) 
    cloudml$trainingInput <- list(scaleTier = "BASIC")
  custom_commands <- cloudml[["customCommands"]]
  cloudml[["customCommands"]] <- NULL
  application <- getwd()
  entrypoint <- file
  entrypoint <- gsub(paste0("^", getwd(), .Platform$file.sep), 
                     "", entrypoint)
  id <- cloudml:::unique_job_name("cloudml")
  deployment <- cloudml:::scope_deployment(id = id, application = application, 
                                 context = "cloudml", overlay = flags, entrypoint = entrypoint, 
                                 cloudml = cloudml, gcloud = gcloud, dry_run = dry_run)
  cloudml_file <- deployment$cloudml_file
  storage <- cloudml:::gs_ensure_storage(gcloud)
  if (is.null(region)) 
    region <- cloudml:::gcloud_default_region()
  job_yml <- file.path(deployment$directory, "job.yml")
  yaml::write_yaml(list(storage = storage, custom_commands = custom_commands), 
                   job_yml)
  directory <- deployment$directory
  cloudml:::scope_setup_py(directory)
  setwd(dirname(directory))
  cloudml_version <- cloudml:::`%||%`(cloudml$trainingInput$runtimeVersion, "1.15")
  if (utils::compareVersion(cloudml_version, "1.4") < 0) 
    stop("CloudML version ", cloudml_version, " is unsupported, use 1.4 or newer.")
  arguments <- (cloudml:::MLArgumentsBuilder(gcloud)
                ("jobs")
                ("submit")
                ("training")(id)
                ("--job-dir=%s", file.path(storage, "staging"))
                ("--package-path=%s", basename(directory))
                ("--module-name=%s.cloudml.deploy", basename(directory))
                ("--runtime-version=%s", cloudml_version)
                ("--python-version=2.7")
                ("--region=%s", region)
                ("--config=%s/%s", "cloudml-model", cloudml_file)
                ("--")
                ("Rscript"))
  gcloud_exec(args = arguments(), echo = FALSE, dry_run = dry_run)
  arguments <- (((cloudml:::MLArgumentsBuilder(gcloud)("jobs"))("describe"))(id))
  output <- gcloud_exec(args = arguments(), echo = FALSE, dry_run = dry_run)
  stdout <- output$stdout
  stderr <- output$stderr
  template <- c("Job '%1$s' successfully submitted.", "%2$s", 
                "Check job status with:     job_status(\"%1$s\")", "", 
                "Collect job output with:   job_collect(\"%1$s\")", "", 
                "After collect, view with:  view_run(\"runs/%1$s\")", 
                "")
  rendered <- sprintf(paste(template, collapse = "\n"), id, 
                      stderr)
  message(rendered)
  description <- yaml::yaml.load(stdout)
  job <- cloudml:::cloudml_job("train", id, description)
  cloudml:::register_job(job)
  if (dry_run) 
    collect <- FALSE
  if (identical(collect, "ask")) {
    if (interactive()) {
      if (cloudml:::have_rstudio_terminal()) 
        response <- readline("Monitor and collect job in RStudio Terminal? [Y/n]: ")
      else response <- readline("Wait and collect job when completed? [Y/n]: ")
      collect <- !nzchar(response) || (tolower(response) == 
                                         "y")
    }
    else {
      collect <- FALSE
    }
  }
  destination <- file.path(application, "runs")
  if (collect) {
    if (have_rstudio_terminal()) {
      cloudml:::job_collect_async(job, gcloud, destination = destination, 
                        view = identical(rstudioapi::versionInfo()$mode, 
                                         "desktop"))
    }
    else {
      cloudml:::job_collect(job, destination = destination, view = interactive())
    }
  }
  invisible(job)
}
