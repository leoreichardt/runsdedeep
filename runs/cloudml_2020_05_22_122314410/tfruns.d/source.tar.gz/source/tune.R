library(keras)
library(here)
library(cloudml)

source(here("scripts/cloud_train2.R"))
setwd("scripts")
#ls_runs(decreasing = T)

#-------------------------------------------------------------------------------
#gs_copy(
#  source = here::here("data/"),
#  destination = "gs://unil-dp-project",
#  recursive = TRUE)

#-------------------------------------------------------------------------------

# Benchmark : test.R - acc = 0.90

# VGG16
# rescale = 1/255
# took 15minutes

# hyperparameter : 

#                 2 layers
#                 200 nodes
#                 0.00001 learning rate
#                 no dropout

#cloud_train2("test.R", master_type = "standard_p100")
job_collect("cloudml_2020_05_22_090225557")
view_run("runs/cloudml_2020_05_22_090225557")

#-------------------------------------------------------------------------------

# Inception_V3 : acc = 0.83 with same hyperparameter than test.R 
# took 31minutes

#                       cloud_train2("train-inception.R", master_type = "standard_p100")
                        job_collect("cloudml_2020_05_22_093026472")
                        view_run("runs/cloudml_2020_05_22_093026472")

#     -----> do not try further

#-------------------------------------------------------------------------------


# VGG16 with preprocessing_function = imagenet_preprocess_input : acc = 0.8940 / 0.8991
# took 36minutes

# 2 models :      200 nodes and 400 nodes
#                 2 layers
#                 0.00001 learning rate
#                 no dropout

#                       cloud_train2("train.tune.rapide.preprocessing.R", master_type = "standard_p100", config = "tuning.yml")
                        job_collect("cloudml_2020_05_22_101255250", trials = "all")
                        view_run("runs/cloudml_2020_05_22_101255250-1") # 200 nodes --> acc : 0.8940
                        view_run("runs/cloudml_2020_05_22_101255250-2") # 400 nodes --> acc : 0.8991


# Benchmark : exactly the same but using rescale = 1/255 : acc = 
#took 16 minutes
                        
#                       cloud_train2("train.tune.rapide.R", master_type = "standard_p100", config = "tuning.yml")
                        job_collect("cloudml_2020_05_22_105430065",  trials = "all")
                        view_run("runs/cloudml_2020_05_22_105430065-1") # 200 nodes --> acc : 0.9096
                        view_run("runs/cloudml_2020_05_22_105430065-2") # 400 nodes --> acc : 0.8929
                        
#     -----> we will go with : rescaling, same accuracy but much faster

#-------------------------------------------------------------------------------

# Transfer learning using VGG16 with rescale = 1/255 ? preprocessing_function = imagenet_preprocess_input

# Hyperparameter tuning 1 : 2 layers 

#                         nodes: better 300 or 600                              PUT JOB COLLECT
#                         learning rate :  0.00005 or 0.00001 or 0.000005       PUT JOB COLLECT
#                         dropout rate : 0.2 or 0.3 or 0.4                      PUT JOB COLLECT

# Final GRID SEARCH :     
#                         nodes : for the best one we will do 200/300/400 or 500/600/700
#                         learning rate : 0.00003/0.00005/0.00007 or 0.000008/0.00001/0.00003 or 0.00000.3/0.000005/0.000007
#                         dropout : the best one
                          
#                         PUT JOB COLLECT
#--- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- ---

# Transfer learning using VGG16 with rescale = 1/255 ? preprocessing_function = imagenet_preprocess_input

# Hyperparameter tuning 2 : 3 layers 

#                         nodes: better 300 or 600                              PUT JOB COLLECT
#                         learning rate :  0.00005 or 0.00001 or 0.000005       PUT JOB COLLECT
#                         dropout rate : 0.2 or 0.3 or 0.4                      PUT JOB COLLECT

# Final GRID SEARCH : 
#                         nodes : for the best one we will do 200/300/400 or 500/600/700
#                         learning rate : 0.00003/0.00005/0.00007 or 0.000008/0.00001/0.00003 or 0.00000.3/0.000005/0.000007
#                         dropout : the best one

#                         PUT JOB COLLECT



#     ---------------> : Best model is : 

