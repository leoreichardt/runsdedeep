library(keras)
library(here)
library(cloudml)

source(here("scripts/cloud_train2.R"))
setwd("scripts")
#ls_runs(decreasing = T)

#-------------------------------------------------------------------------------
#gs_copy(
#  source = here::here("data/"),
#  destination = "gs://unil-dp-project",
#  recursive = TRUE)

#-------------------------------------------------------------------------------

# Benchmark : test.R - acc = 0.90

# VGG16
# rescale = 1/255
# took 15minutes

# hyperparameter : 

#                 2 layers
#                 200 nodes
#                 0.00001 learning rate
#                 no dropout

#cloud_train2("test.R", master_type = "standard_p100")
job_collect("cloudml_2020_05_22_090225557")
view_run("runs/cloudml_2020_05_22_090225557")

#-------------------------------------------------------------------------------

# Inception_V3 : acc = 0.83 with same hyperparameter than test.R 
# took 31minutes

#                       cloud_train2("train-inception.R", master_type = "standard_p100")
                        job_collect("cloudml_2020_05_22_093026472")
                        view_run("runs/cloudml_2020_05_22_093026472")

#     -----> do not try further

#-------------------------------------------------------------------------------

# target_size(300) / input_shape(300) : acc = 0.9314 with same hyperparameter than test.R
#took 18minutes
                        
#cloud_train2("test300.R", master_type = "standard_p100")
job_collect("cloudml_2020_05_22_112053286")   
view_run("runs/cloudml_2020_05_22_112053286")
                        
#    -----> improves a lot however, weird did not notice but images size is 200x200 : acc = 0.9160                                             

# Try again with target_size(200) / input_shape(200)
#cloud_train2("test300.R", master_type = "standard_p100")
job_collect("cloudml_2020_05_22_122314410") 
view_run("runs/cloudml_2020_05_22_122314410")

#    -----> still improves but less? why?                                                

# Try again with 450x450 : acc = 0.8776
#cloud_train2("test300.R", master_type = "standard_p100")
job_collect("cloudml_2020_05_22_124403254") 
view_run("runs/cloudml_2020_05_22_124403254")

#    -----> this this reduce accuracy

# let's use target_size(300)

#-------------------------------------------------------------------------------
                        
# VGG16 with preprocessing_function = imagenet_preprocess_input : acc = 0.8940 / 0.8991
# took 36minutes

# 2 models :      200 nodes and 400 nodes
#                 2 layers
#                 0.00001 learning rate
#                 no dropout

#                       cloud_train2("train.tune.rapide.preprocessing.R", master_type = "standard_p100", config = "tuning.yml")
                        job_collect("cloudml_2020_05_22_101255250", trials = "all")
                        view_run("runs/cloudml_2020_05_22_101255250-1") # 200 nodes --> acc : 0.8940
                        view_run("runs/cloudml_2020_05_22_101255250-2") # 400 nodes --> acc : 0.8991


# Benchmark : exactly the same but using rescale = 1/255 : acc = 0.9096 / 0.8929
#took 16 minutes
                        
#                       cloud_train2("train.tune.rapide.R", master_type = "standard_p100", config = "tuning.yml")
                        job_collect("cloudml_2020_05_22_105430065",  trials = "all")
                        view_run("runs/cloudml_2020_05_22_105430065-1") # 200 nodes --> acc : 0.9096
                        view_run("runs/cloudml_2020_05_22_105430065-2") # 400 nodes --> acc : 0.8929
                        
#     -----> we will go with : rescaling, almost same accuracy but much faster

#-------------------------------------------------------------------------------
                        
# Transfer learning using VGG16 with rescale = 1/255 and input_shape(200)

# Hyperparameter tuning 1 : 2 layers 

#                         nodes: 200, 400, 600                            
#                         learning rate :  0.0001 or 0.00001 or 0.000001       
#                         dropout rate : 0.2 or 0.3 or 0.4                      

cloud_train2("train.tune.rapide.R", master_type = "standard_p100", config = "tuning.2.yml")                       

#-------------------------------------------------------------------------------

# test fine tuning : same as test.R but with input shape = 200
                        
view_run("runs/cloudml_2020_05_25_152125823") # 91.6%

# test fine tune augmented : same as fine tune with augmented training set
cloud_train2("test.fine.tune.augmented.R", master_type = "standard_p100")
job_collect("cloudml_2020_05_25_184624989") # 0.9319


                        
                                              
                          